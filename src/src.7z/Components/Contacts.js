import React, {Component} from 'react';
import Contact from './Contact';

class Contacts extends React.Component {

	constructor() {
		super();
		this.state = {
			arr: [
				{
					name: 'Stefan',
					email: "asd@gmaill.com",
					phone: "12345"
				},
				{
					name: 'Stefan',
					email: "asd@gmaill.com",
					phone: "00000"
				},
				{
					name: 'Stefan',
					email: "asd@gmaill.com",
					phone: "1111"
				}
			]
		}
	}

	render() {
		return (
			<div className="Contacts">
				{
					this.state.arr.map((element,index)=>{
						return(
								<Contact key={index} id={index} name={element.name} email={element.email} phone={element.phone}  />
							)
					})
				}
			</div>
		);
	}
}
export default Contacts;