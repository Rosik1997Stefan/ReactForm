import React, {Component} from 'react';

class AddContact extends React.Component {


	constructor() {
		super();
		this.state = {
			id: undefined,
			name: "",
			email: "",
			phone: "",
			errors: []
		}
	}

	render() {
		return (
			<div className="AddContact">
				<h2>Add Contact</h2>
				<form>
					<label htmlFor="name">Name</label>
					<br/>
					<input type="text" name="name" className="is-invalid" placeholder="Enter Name..."  />
					<br/>
					<p></p>
					<label htmlFor="email">Email</label>
					<br/>
					<input type="text" name="email" placeholder="Enter Email..." />
					<br/>
					<p></p>
					<label htmlFor="phone">Phone</label>
					<br/>
					<input type="text" name="phone" placeholder="Enter Phone..." />
					<br/>
					<p></p>

					<button>Add</button>
				</form>

			</div>
		);
	}
}
export default AddContact;